#!/usr/bin/env python3
"""Score one benchmark round from its stream-json transcript (SL-228 PHASE-07 T8).

Reads the raw .jsonl and reports the measurement record: cost, completion, the
funnel ladder the subject actually walked, the refusals it met, whether it ever
reached for memory (VA-1's blindness check), and where it asked for help
(STOP-2's rescue datum).
"""
import json
import re
import sys

LADDER = ["setup", "arm-spawn", "worker_commit", "import", "verify", "conclude", "reap", "next"]
REFUSAL_MARKERS = [
    "undeclared-scope", "not-landed", "verify-tree-dirty", "conclude-verify-stale",
    "unknown-agent", "unknown-slice", "gc-incomplete", "claim-busy",
    "ambiguous-fork-row", "verify-suite-unresolved", "Refused", "refused", "refuse",
]
STUCK_MARKERS = ["stuck", "I need", "cannot proceed", "unable to", "would need", "blocked"]


def load(path):
    for line in open(path):
        line = line.strip()
        if line:
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                continue


def text_of(content):
    out = []
    for b in content if isinstance(content, list) else []:
        if b.get("type") == "text":
            out.append(b.get("text", ""))
    return "\n".join(out)


def main(path):
    tools, bash_cmds, mcp_calls, memory_calls = [], [], [], []
    refusals, result, agent_spawns = [], None, 0
    assistant_text = []
    # tool_use_id -> tool name. A refusal only counts if it came back from a
    # command (Bash / MCP), never from the CONTENT of a file the subject read —
    # skill docs and source both quote refusal tokens verbatim.
    origin = {}

    for e in load(path):
        t = e.get("type")
        if t == "result":
            result = e
        elif t == "assistant":
            content = e.get("message", {}).get("content", [])
            assistant_text.append(text_of(content))
            for b in content if isinstance(content, list) else []:
                if b.get("type") != "tool_use":
                    continue
                name = b.get("name", "")
                tools.append(name)
                origin[b.get("id")] = name
                inp = b.get("input", {})
                if name == "Bash":
                    bash_cmds.append(inp.get("command", ""))
                elif name == "Agent" or name == "Task":
                    agent_spawns += 1
                if "mcp__doctrine__" in name:
                    mcp_calls.append(name.split("mcp__doctrine__")[-1])
                if "memory" in name.lower():
                    memory_calls.append(name)
        elif t == "user":
            content = e.get("message", {}).get("content", [])
            for b in content if isinstance(content, list) else []:
                if b.get("type") == "tool_result":
                    src = origin.get(b.get("tool_use_id"), "")
                    if src != "Bash" and "mcp__doctrine__" not in src:
                        continue
                    c = b.get("content")
                    s = c if isinstance(c, str) else json.dumps(c)
                    # A `cat`/`grep` of a skill or source file is a file read wearing
                    # Bash's clothes — exclude by the shapes those dumps always carry.
                    if re.search(r"^\s*\d+→|^---\s*$|^name:\s|pub\(crate\) fn |^\s*///", s, re.M):
                        continue
                    for m in REFUSAL_MARKERS:
                        if m in s:
                            snippet = re.sub(r"\s+", " ", s)[:300]
                            refusals.append((m, snippet, src))
                            break

    doctrine_cmds = [c for c in bash_cmds if "doctrine" in c]
    for c in doctrine_cmds:
        if re.search(r"memory\s", c):
            memory_calls.append("bash:" + c[:60])

    print(f"=== {path.split('/')[-1]} ===")
    if result:
        u = result.get("usage", {})
        print(f"terminal_reason : {result.get('terminal_reason')}  is_error={result.get('is_error')}")
        print(f"num_turns       : {result.get('num_turns')}")
        print(f"cost_usd        : {round(result.get('total_cost_usd', 0), 4)}")
        print(f"tokens in/out   : {u.get('input_tokens')}/{u.get('output_tokens')}"
              f"  cache r/w: {u.get('cache_read_input_tokens')}/{u.get('cache_creation_input_tokens')}")
        print(f"session_id      : {result.get('session_id')}")
    else:
        print("NO RESULT EVENT — subject died, timed out, or was cut off")

    print(f"\ntool calls      : {len(tools)}  (bash {len(bash_cmds)}, worker spawns {agent_spawns})")
    print(f"memory reaches  : {len(memory_calls)}   <-- VA-1 blindness check: must be 0")
    for m in memory_calls:
        print(f"    ! {m}")

    print(f"\nfunnel ladder walked ({len(mcp_calls)} MCP calls):")
    for i, c in enumerate(mcp_calls, 1):
        print(f"  {i:3}. {c}")

    print(f"\ndoctrine CLI invocations ({len(doctrine_cmds)}):")
    for c in doctrine_cmds:
        print(f"  - {re.sub(r'\\s+', ' ', c)[:150]}")

    print(f"\nrefusals / typed errors met ({len(refusals)}):")
    seen = set()
    for marker, snippet, src in refusals:
        if marker in seen:
            continue
        seen.add(marker)
        print(f"  [{marker}] ({src}) {snippet}")

    tail = assistant_text[-1] if assistant_text else ""
    print("\nfinal report (tail):")
    print("  " + "\n  ".join(tail.strip().splitlines()[-40:]))


if __name__ == "__main__":
    main(sys.argv[1])
