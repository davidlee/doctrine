#!/usr/bin/env bash
# S4 setup — simulate a dead orchestrator context by killing the subject the
# instant a given funnel marker lands. The kill must look like a crash, not a
# clean shutdown: no chance to summarise, hand over, or tidy the record.
# Usage: kill-at.sh <marker> [max-wait-secs]
set -u
BENCH=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
CLONE="$BENCH/repo"
MARKER="${1:-worker_commit}"
MAXWAIT="${2:-1800}"
END=$(( $(date +%s) + MAXWAIT ))

echo "[kill-at] watching dispatch/230 funnel record for '$MARKER'"
while [ "$(date +%s)" -lt "$END" ]; do
  rec=$(git -C "$CLONE" show dispatch/230:.doctrine/dispatch/230/funnel.toml 2>/dev/null || true)
  if printf '%s' "$rec" | grep -q "$MARKER"; then
    echo "[kill-at] '$MARKER' present — killing the subject NOW"
    printf '%s' "$rec" | head -30
    pkill -9 -f "bwrap.*claude" 2>/dev/null
    pkill -9 -f "bench-spawn.sh" 2>/dev/null
    echo "[kill-at] killed at $(date -u +%H:%M:%S)"
    exit 0
  fi
  sleep 5
done
echo "[kill-at] marker never appeared within ${MAXWAIT}s — no kill issued"
exit 1
