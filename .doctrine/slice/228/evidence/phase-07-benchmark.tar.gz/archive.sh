#!/usr/bin/env bash
# Freeze a round's end-state BEFORE the substrate is restored for the next round.
# S0's per-rung funnel rows were lost to a restore; this exists so that cannot
# happen twice. Usage: archive.sh <round-label>
set -u
BENCH=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
CLONE="$BENCH/repo"
LABEL="$1"
OUT="$BENCH/end-states/$LABEL"
mkdir -p "$OUT"
B="${BENCH_DOCTRINE_BIN:-/workspace/doctrine/.dispatch/SL-228/target/debug/doctrine}"

git -C "$CLONE" show "dispatch/230:.doctrine/dispatch/230/funnel.toml" > "$OUT/funnel.toml" 2>&1
git -C "$CLONE" show "dispatch/230:.doctrine/dispatch/230/boundaries.toml" > "$OUT/boundaries.toml" 2>&1
git -C "$CLONE" log --oneline --all --decorate > "$OUT/git-log.txt" 2>&1
git -C "$CLONE" branch -a > "$OUT/branches.txt" 2>&1
git -C "$CLONE" status --porcelain > "$OUT/status.txt" 2>&1
(cd "$CLONE" && "$B" dispatch status --slice 230) > "$OUT/dispatch-status.txt" 2>&1
(cd "$CLONE" && "$B" dispatch next --slice 230) > "$OUT/dispatch-next.txt" 2>&1
for f in catalog registry index; do
  git -C "$CLONE" show "dispatch/230:bench/$f.md" > "$OUT/bench-$f.md" 2>&1
done
echo "[archive] $LABEL -> $OUT"
ls "$OUT"
