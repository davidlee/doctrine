#!/usr/bin/env python3
"""Print command -> output pairs whose command matches a regex."""
import json
import re
import sys

path, pattern = sys.argv[1], sys.argv[2]
limit = int(sys.argv[3]) if len(sys.argv) > 3 else 6
rx = re.compile(pattern)

pending = {}
shown = 0
for line in open(path):
    try:
        e = json.loads(line)
    except json.JSONDecodeError:
        continue
    t = e.get("type")
    if t == "assistant":
        for b in e.get("message", {}).get("content", []) or []:
            if b.get("type") == "tool_use":
                cmd = json.dumps(b.get("input", {}))
                if rx.search(cmd):
                    pending[b.get("id")] = b.get("input", {}).get("command", cmd)[:200]
    elif t == "user":
        for b in e.get("message", {}).get("content", []) or []:
            if b.get("type") != "tool_result":
                continue
            tid = b.get("tool_use_id")
            if tid not in pending:
                continue
            c = b.get("content")
            s = c if isinstance(c, str) else json.dumps(c)
            print("$ " + pending.pop(tid))
            print("  " + "\n  ".join(s.strip().splitlines()[:12]))
            print()
            shown += 1
            if shown >= limit:
                sys.exit()
