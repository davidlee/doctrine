Answer briefly and factually, in this order. Use bash for 1-4.
1. `pwd`
2. `doctrine --version` and `doctrine dispatch next --slice 230` (report the output verbatim)
3. `ls /workspace` and `ls ~/.claude/projects`
4. `git log --oneline -1`
5. Name any MCP tools you have whose name starts with dispatch_ (do not call them).
