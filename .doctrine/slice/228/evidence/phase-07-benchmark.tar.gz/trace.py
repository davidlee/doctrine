#!/usr/bin/env python3
"""Print a round's dispatch-relevant action trace, in order."""
import json
import re
import sys

path = sys.argv[1]
limit = int(sys.argv[2]) if len(sys.argv) > 2 else 20
n = 0
for line in open(path):
    try:
        e = json.loads(line)
    except json.JSONDecodeError:
        continue
    if e.get("type") != "assistant":
        continue
    for b in e.get("message", {}).get("content", []) or []:
        if b.get("type") != "tool_use":
            continue
        nm = b.get("name", "")
        inp = json.dumps(b.get("input", {}))
        if "mcp__doctrine__" in nm or "dispatch" in inp:
            n += 1
            if n <= limit:
                label = nm.replace("mcp__doctrine__", "MCP:")
                print(f"{n:3}. {label} | {re.sub(r'[ \t\n]+', ' ', inp)[:140]}")
print(f"... {n} dispatch-relevant actions total")
