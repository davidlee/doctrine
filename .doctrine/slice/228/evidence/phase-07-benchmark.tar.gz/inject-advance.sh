#!/usr/bin/env bash
# S5 injection — "the fork advanced past its imported tip".
#
# Watches the funnel record for a phase's `[phase.import]` row and, the instant it
# lands, advances that fork branch by one commit. Reap must then refuse: D9's
# landing proof requires the live branch OID to equal the row's `import.fork_tip`
# (RV-308 F-1 — a branch carrying work beyond what was imported must not be deleted).
#
# The advance is done with commit-tree + update-ref so no worktree is touched: the
# fork's checkout, if any, is left exactly as the worker left it.
#
# Usage: inject-advance.sh <fork-branch> [max-wait-secs]
set -u
BENCH=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
CLONE="$BENCH/repo"
FORK="${1:-dispatch/sl230-p01}"
MAXWAIT="${2:-1800}"
END=$(( $(date +%s) + MAXWAIT ))

echo "[inject] watching for [phase.import] to advance $FORK"
while [ "$(date +%s)" -lt "$END" ]; do
  rec=$(git -C "$CLONE" show dispatch/230:.doctrine/dispatch/230/funnel.toml 2>/dev/null || true)
  if printf '%s' "$rec" | grep -q '\[phase.import\]'; then
    tip=$(git -C "$CLONE" rev-parse "$FORK" 2>/dev/null) || { echo "[inject] $FORK gone already"; exit 1; }
    tree=$(git -C "$CLONE" rev-parse "$FORK^{tree}")
    new=$(git -C "$CLONE" commit-tree "$tree" -p "$tip" \
            -m "wip(SL-230): late work pushed to the fork after import (S5 injection)")
    git -C "$CLONE" update-ref "refs/heads/$FORK" "$new"
    echo "[inject] $FORK advanced $tip -> $new"
    printf '%s' "$rec" | grep -A2 '\[phase.import\]'
    exit 0
  fi
  sleep 3
done
echo "[inject] import never landed within ${MAXWAIT}s — no injection"
exit 1
