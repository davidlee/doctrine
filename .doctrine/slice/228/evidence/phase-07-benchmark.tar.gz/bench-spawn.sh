#!/usr/bin/env bash
# OQ-5 memory-blind benchmark — subject spawn (SL-228 PHASE-07, T4).
#
# Spawns the SUBJECT: a headless `claude -p` orchestrator whose cwd is the
# prepared clone, with its OWN doctrine MCP server bound to that clone's root
# (--mcp-config + --strict-mcp-config). Structure mirrors pi-spawn-confined.sh —
# same confinement idea, same "one wrapper around the exec" shape; no second
# pattern invented.
#
# Confinement: --ro-bind / / makes the whole fs read-only, then rw is re-granted
# to $HOME (claude writes ~/.claude.json and ~/.claude/) and to the clone. The
# real repo at /workspace stays READ-ONLY — the subject cannot touch it even
# under --dangerously-skip-permissions, which is what makes that flag safe here.
#
# Usage: bench-spawn.sh <round-label> <prompt-file> [resume-session-id]
set -u
LABEL="$1"
PF="$2"
RESUME="${3:-}"

BENCH=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
CLONE="$BENCH/repo"
RAW="$BENCH/raw/$LABEL.jsonl"
MODEL="${BENCH_MODEL:-claude-opus-5}"
MAXTURNS="${BENCH_MAX_TURNS:-120}"
BACKSTOP="${BENCH_BACKSTOP:-3600}"

[ -d "$CLONE" ] || { echo "[bench] no clone at $CLONE" >&2; exit 1; }
[ -f "$PF" ] || { echo "[bench] no prompt file at $PF" >&2; exit 1; }
mkdir -p "$BENCH/raw"

RESUME_ARGS=()
[ -n "$RESUME" ] && RESUME_ARGS=(--resume "$RESUME")

BIN="${BENCH_DOCTRINE_BIN:-/workspace/doctrine/.dispatch/SL-228/target/debug/doctrine}"
[ -x "$BIN" ] || { echo "[bench] no doctrine binary at $BIN" >&2; exit 1; }

# Order is load-bearing: each --tmpfs masks a contamination surface, and the
# binds that follow re-expose only what the subject legitimately needs.
PREFIX=( bwrap
  --ro-bind / /
  --dev /dev --proc /proc
  --bind "$HOME" "$HOME"
  --tmpfs "$HOME/.claude/projects"        # this session's transcripts — the exam paper
  --tmpfs /workspace                      # the real repo — SL-228 notes/handover/case-notes
  --tmpfs /tmp                            # writable tmp (the shell needs it); also hides
                                          # repo.pristine, raw/ and the prompts
  --ro-bind "$BIN" "$HOME/.cargo/bin/doctrine"  # PATH `doctrine` must be the FUNNEL-CAPABLE
                                          # binary; the jail's stock 0.29 has no `dispatch
                                          # next`, and a subject concluding the verb does
                                          # not exist would poison the measurement
  --bind "$CLONE" "$CLONE"                # re-exposed into the fresh /tmp
  --chdir "$CLONE"
  --die-with-parent )

# Fail-closed: an empty confinement prefix must never fall through to an
# unconfined subject with --dangerously-skip-permissions (pi-spawn-confined EX-2).
[ "${#PREFIX[@]}" -gt 0 ] || { echo "[bench] empty confinement PREFIX — aborting" >&2; exit 1; }

echo "[bench] round=$LABEL model=$MODEL resume=${RESUME:-none} clone=$CLONE"
timeout "$BACKSTOP" "${PREFIX[@]}" \
  claude -p "$(cat "$PF")" \
  --output-format stream-json --verbose \
  --model "$MODEL" \
  --max-turns "$MAXTURNS" \
  --mcp-config "$CLONE/.mcp.json" --strict-mcp-config \
  --dangerously-skip-permissions \
  "${RESUME_ARGS[@]}" \
  >"$RAW" 2>&1
RC=$?

echo "[bench] exit=$RC raw=$RAW"
echo "----- result event -----"
grep '"type":"result"' "$RAW" | tail -1 |
  python3 -c 'import json,sys
try:
  r = json.loads(sys.stdin.read())
except Exception:
  print("no result event — subject died or was cut off"); raise SystemExit
u = r.get("usage", {})
print("session_id     :", r.get("session_id"))
print("terminal_reason:", r.get("terminal_reason"), "| is_error:", r.get("is_error"), "| num_turns:", r.get("num_turns"))
print("cost_usd       :", round(r.get("total_cost_usd", 0), 4))
print("tokens in/out  :", u.get("input_tokens"), "/", u.get("output_tokens"),
      "| cache r/w:", u.get("cache_read_input_tokens"), "/", u.get("cache_creation_input_tokens"))
print("denials        :", len(r.get("permission_denials", [])))'
