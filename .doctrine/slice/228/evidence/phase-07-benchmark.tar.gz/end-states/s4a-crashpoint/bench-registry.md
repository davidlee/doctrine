# Registry

Registered entries, one row each.

