# Registry

Registered entries, one row each.
- delta: the first registered entry, cross-linked from the index

